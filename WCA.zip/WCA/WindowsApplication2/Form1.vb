﻿Public Class Form1
    Private Sub Label5_Click(sender As Object, e As EventArgs) Handles Label5.Click

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim winds As Double
        Dim winda As Double
        Dim head As Double
        Dim trus As Double
        Dim WCA As Double
        Dim awa As Double
        Dim MH As Double

        winds = CDbl(WS.Text)
        winda = CDbl(WA.Text)
        head = CDbl(Heading.Text)
        trus = CDbl(TAS.Text)
        awa = winda - head

        WCA = (Math.Asin(winds * (Math.Sin(awa) / trus))) * (180 / 3.14159)
        MH = WCA + head
        Label6.Text = "WCA " + Str(Math.Round(WCA)) + " " + "MH " + Str(Math.Round(MH))





    End Sub

    Private Sub TAS_TextChanged(sender As Object, e As EventArgs) Handles TAS.TextChanged

    End Sub

    Private Sub WS_TextChanged(sender As Object, e As EventArgs) Handles WS.TextChanged

    End Sub

    Private Sub WA_TextChanged(sender As Object, e As EventArgs) Handles WA.TextChanged

    End Sub

    Private Sub Heading_TextChanged(sender As Object, e As EventArgs) Handles Heading.TextChanged

    End Sub

    Private Sub Label6_Click(sender As Object, e As EventArgs) Handles Label6.Click

    End Sub
End Class
