﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Microsoft.Win32;
using Excel = Microsoft.Office.Interop.Excel;

namespace Quizbuddy
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
      
        public string quiz;
        public int i=1;
        public string qcellValue;
        public string acellValue;
        public string savePath;
        // public Label label = new Label();

        private void About_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Quiz Buddy by \nMartin Johnson", "About");
        }

        private void openFile_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            if (openFileDialog.ShowDialog() == true)
                quiz = openFileDialog.FileName;
            xl();
        }

        private void Start_Click(object sender, RoutedEventArgs e)
        {
            //label.Content = "fucking work";
            //textBlock.Text = "gello";
        }

        private void questionBox_TextChanged(object sender, TextChangedEventArgs e)
        {
           
        
        }

        private void Submit_Click(object sender, RoutedEventArgs e)
        {
            // if qcellvalue compares to acellvalue correct
            //else try again
            try
            {
                if (answerBox.Selection.Text.ToLower() == acellValue.ToLower())
                {
                    textBlock.Text = "Correct";
                }
                else
                {
                    textBlock.Text = "Try Again";
                }
            }catch { }
        }

        private void Show_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                answerBox.Document.Blocks.Clear();
                answerBox.Selection.Text = acellValue;
            }
            catch { }
            
        }

        private void Next_Click(object sender, RoutedEventArgs e)
        {
            i++;
            xl();
            textBlock.Text = " ";
            answerBox.Document.Blocks.Clear();
            
        }
   
        public void xl()//reading
        {
            try{
                Excel.Application excelApp = new Excel.Application();
                if (excelApp != null)
                {
                    Excel.Workbook excelWorkbook = excelApp.Workbooks.Open(quiz, 0, true, 5, "", "", true, Excel.XlPlatform.xlWindows, "\t", false, false, 0, true, 1, 0);
                    Excel.Worksheet excelQuestions = (Excel.Worksheet)excelWorkbook.Sheets["Questions"];
                    Excel.Worksheet excelAnswers = (Excel.Worksheet)excelWorkbook.Sheets["Answers"];
                    Excel.Range excelRange = excelQuestions.UsedRange;
                    int rowCount = excelRange.Rows.Count;


                    // for (int i = 1; i <= rowCount; i++)
                    //{
                    // Excel.Range range = (excelQuestions.Cells[i, 1] as Excel.Range);
                    qcellValue = excelQuestions.Cells[i, 1].value;
                    questionBox.Selection.Text = qcellValue;

                    acellValue = excelAnswers.Cells[i, 1].value;


                    // }

                    excelWorkbook.Close();
                    excelApp.Quit();
                }
            }catch 
            {
                MessageBox.Show("No Quiz Loaded", "Error");
            }
        }

        public void xlWrite()
        {
            Excel.Application excelApp = new Excel.Application();
            if (excelApp != null)
            {
                Excel.Workbook excelWorkbook = excelApp.Workbooks.Add();
                Excel.Worksheet excelQuestions = (Excel.Worksheet)excelWorkbook.Sheets.Add();
                Excel.Worksheet excelAnswers = (Excel.Worksheet)excelWorkbook.Sheets.Add();
                excelQuestions.Name = "Questions";
                excelAnswers.Name = "Answers";
                excelQuestions.Cells[1, 1] = "Value1";
                //excelans.Cells[2, 1] = "Value2";
                excelQuestions.Cells[3, 1] = "Value3";
                excelQuestions.Cells[4, 1] = "Value4";

                //excelApp.ActiveWorkbook.SaveAs(savePath, Excel.XlFileFormat.xlWorkbookNormal);
                excelApp.ActiveWorkbook.SaveAs(savePath, Excel.XlFileFormat.xlWorkbookDefault);
                excelWorkbook.Close();
                excelApp.Quit();
                /*
                System.Runtime.InteropServices.Marshal.FinalReleaseComObject(excelAnswers);
                System.Runtime.InteropServices.Marshal.FinalReleaseComObject(excelQuestions);
                System.Runtime.InteropServices.Marshal.FinalReleaseComObject(excelWorkbook);
                System.Runtime.InteropServices.Marshal.FinalReleaseComObject(excelApp);
                GC.Collect();
                GC.WaitForPendingFinalizers();*/
            }

        }

        private void backBtn_Click(object sender, RoutedEventArgs e)
        {
            i--;
            xl();
            textBlock.Text = " ";
            answerBox.Document.Blocks.Clear();

        }

        private void Save_Click(object sender, RoutedEventArgs e)
        {
            
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            if (saveFileDialog.ShowDialog() == true)
            {
                savePath = saveFileDialog.FileName;
            }
            xlWrite();
       
        }
    }
}
